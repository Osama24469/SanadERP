# SanadERP
Basic structure generated.