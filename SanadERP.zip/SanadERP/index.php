<?php
include 'includes/header.php';
echo '<h1>Welcome to SanadERP</h1>';
include 'includes/footer.php';
